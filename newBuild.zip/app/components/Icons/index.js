import IssueIcon from './IssueIcon';

export { IssueIcon };

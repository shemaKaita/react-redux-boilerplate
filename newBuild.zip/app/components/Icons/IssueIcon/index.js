export { default } from './IssueIcon';

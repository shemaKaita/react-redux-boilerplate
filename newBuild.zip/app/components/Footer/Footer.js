import React from 'react';
import './style.scss';

const Footer = () => (
  <footer>
  </footer>
);

export default Footer;
